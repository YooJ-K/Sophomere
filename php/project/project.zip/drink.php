<!DOCTYPE html>
<html>

<head>
  <title>24 study cafe</title>
</head>

<body>
  <center>
    <?php include "header.php";?>

    <?php include "footer.php";?>
  </center>
</body>

</html>
