<!DOCTYPE html>
<html>
  <head>
    <title>24 study cafe</title>
    <style>

      #headf{
        text-align:center;
      }
      #login {
        position: relative;
        width: 2500px;
        margin: 0 auto;
      }

      a:link{
        text-decoration: none;
        color:black;
      }

      a:visited{
        text-decoration: none;
        color:black;
      }

      a:active{
        text-decoration: none;
        color:black;
      }

      a:hover{
        text-decoration: none;
        color:red;
      }

    </style>
  </head>
  <body>
    <div id = "headf">
      <h5 id="login"><a href="join.php">회원가입</a> | <a href="login.php">로그인</a></h5>
      <a href="main.php"><img src="pic/header.png" width="1200"></a>
    </div>
  </body>
</html>
