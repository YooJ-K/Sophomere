<style media="screen">
.footer {
  background-color: #d4d4d4;
  color: white;
  text-align: center;
}
</style>

<footer class="footer">
  <h6><br>24 STUDY CAFE<br><br>
    부산광역시 부산진구 엄광로 176<br><br>
    ⓒ깔깔깔<br><br></h6>


</footer>
