<!DOCTYPE html>
<html lang="" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>24 study cafe</title>
</head>

  <body>
    <center>
      <?php include "header.php";?>
      <!--center 수정 필요함.-->
      <table>
        <tr>
          <td>
            <a href="seat.php">
              <img src="pic/좌석 배정.png" width="200px" alt="">
            </a>
          </td>
          <td>
            <a href="time.php">
              <img src="pic/시간.png" width="200px" alt="">
            </a>
          </td>

          <td><a href="goods.php"><img src="pic/대여 안내.png" width="200px" alt=""></a></td>
          <td><a href="quesion.php"><img src="pic/자주 묻는 질문.png" width="200px" alt=""></a></td>
        </tr>
      </table>

      <br><br>
      <br><br>

      <?php include "footer.php";?>
    </center>
  </body>

  </html>
